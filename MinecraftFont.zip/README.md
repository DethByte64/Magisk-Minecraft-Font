# Magisk-Minecraft-Font
A Magisk Module that changes your default font to the Minecraft font
___

I wanted the minecraft font on my device so i found this font here: https://www.fontspace.com/minecraft-font-f28180
The font is Public Domain, so no legal issues here.

I cant guarantee that it will work on every device, but it works on mine. (Pixel 5, ProtonAOSP, Magisk)
